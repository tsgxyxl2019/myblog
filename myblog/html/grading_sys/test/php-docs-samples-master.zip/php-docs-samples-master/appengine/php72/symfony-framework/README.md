## Run Symfony on App Engine Standard for PHP 7.2

See the [Community Tutorial](https://cloud.google.com/community/tutorials/run-symfony-on-appengine-standard) for complete instructions.

To file issues or contribute changes, see [the GitHub repository](https://github.com/GoogleCloudPlatform/community/blob/master/tutorials/run-symfony-on-appengine-standard/index.md).
