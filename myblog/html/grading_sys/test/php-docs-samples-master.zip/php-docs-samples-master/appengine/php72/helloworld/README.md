# Hello World on App Engine Standard for PHP 7.2

This sample demonstrates how to deploy a *very* basic application to Google
App Engine for PHP 7.2.

## View the [full tutorial](https://cloud.google.com/appengine/docs/standard/php7/quickstart)
