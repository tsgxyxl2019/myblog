# WordPress on App Engine Standard for PHP 7.2

Please refer to [the community tutorial](https://cloud.google.com/community/tutorials/run-wordpress-on-appengine-standard) for running the code in this sample.
