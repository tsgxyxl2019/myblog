# Laravel Framework on App Engine Standard for PHP 7.2

To run this sample, read the [Run Laravel on App Engine Standard][tutorial] tutorial. 

[tutorial]: https://cloud.google.com/community/tutorials/run-laravel-on-appengine-standard
