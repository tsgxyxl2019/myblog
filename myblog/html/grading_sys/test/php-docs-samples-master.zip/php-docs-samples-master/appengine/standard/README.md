## App Engine Standard samples are now in [appengine/php55](../php55) and
## [appengine/php72](../php72) for PHP 5.5 and PHP 7.2 versions of App Engine
## Standard respectively.