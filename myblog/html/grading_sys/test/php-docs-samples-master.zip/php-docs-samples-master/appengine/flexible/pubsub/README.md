# Google PubSub PHP Sample Application for App Engine Flexible Environment.

## Description

This sample demonstrates how to invoke PubSub from Google App Engine Flexible
Environment. See the section **Deploy to App Engine Flexible** in [Google PubSub PHP Sample Application](../../../pubsub/app).

