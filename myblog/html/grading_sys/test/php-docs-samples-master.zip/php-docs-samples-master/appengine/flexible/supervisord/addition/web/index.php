<?php

echo file_get_contents('/tmp/currentQuote');
